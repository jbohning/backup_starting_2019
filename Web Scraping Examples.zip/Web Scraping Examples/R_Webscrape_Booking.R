#Load the needed packages
library(rvest)
library(ggplot2)
library(gridExtra)
library(RSelenium)
library(wdman)
library(plyr)
library(dplyr)

#Enter url
mainurl<-"https://www.booking.com/country.html?aid=304142;label=gen173nr-1DCAEoggI46AdIM1gEaJ0CiAEBmAExuAEHyAEM2AED6AEB-AECiAIBqAIDuAKQ4cLtBcACAQ;sid=fc5144f2838aee14358181bb56fbfd00"

#Set up browser connection
pDrv <- phantomjs(port = 4567L)
remDr <- remoteDriver(browserName = "phantomjs", port = 4567L)
remDr$open(silent=TRUE)
remDr$navigate(mainurl)

#Let the page load by waiting 10 seconds
Sys.sleep(10)

#Pull relevant data
#Grab the whole page's data
all_countries <- read_html(remDr$getPageSource()[[1]])%>%
        html_nodes(".block_third--flag-module") %>%
        html_text()
#Grab just the data for the UK
england<-read_html(remDr$getPageSource()[[1]]) %>%
        html_nodes(".block_third--flag-module:nth-child(147)") %>%
        html_text()

# Close session (exits browser)
remDr$close()
pDrv$stop()

head(all_countries)
head(england)

##############################################
#OPTIONAL: CLEAN DATA
##############################################

#Clean up the UK data:
#Turn the string into separate values/rows based on the line break (\n)
#And convert to character vector (ie unlist)
england_cleaned<-strsplit(england, split = "\n")[[1]]

#remove blanks
england_cleaned<-england_cleaned[!england_cleaned == '']

#Save data off. Because this code was run daily, paste
#the data to the file name so that you can combine later
write.csv(england_cleaned,paste0("united_kingdom_",Sys.Date(),".csv"))



#Clean up the data with all of the countries info
#Turn the string into separate values/rows based on the line break (\n)
all_countries_cleaned<-strsplit(all_countries, split = "\n")

#Loop through the full length of the list to clean up each countrie
#Initiate Data Frame with a NULL
edited_countries<-NULL
for (i in 1:length(all_countries_cleaned)){
        #Grab one country's data (each item in the list is a country)
        temp<-all_countries_cleaned[[i]]
        #remove blanks
        temp<-temp[!temp == '']
        #First value is the country name
        country_name=temp[1]
        #Second value is sub-country info, so it can be ignored
        #Keep from value 3 and one
        values<-temp[3:length(temp)]
        #Remove the commas from the numbers
        values<-gsub(pattern=",",replacement = "", values)
        #Split numbers from words (remove commas from numbers)
        numbers<-as.numeric(gsub(pattern="([0-9]+).*$", "\\1",values))
        words<-as.character(trimws(gsub(pattern="[0-9]", "",values)))
        output<-data.frame(country_name,t(numbers))
        names(output)<-c("Country",words)
        edited_countries<-rbind.fill(edited_countries,output)
}

#Save data off. Because this code was run daily, paste
#the data to the file name so that you can combine later
write.csv(edited_countries,paste0("country_data_",Sys.Date(),".csv"))







