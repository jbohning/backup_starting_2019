#This example grabs stock prices from the WSJ for the tickers provide

library(rvest)
library(dplyr)


ticker_symbols <- c('AAPL', 'FB', 'GOOGL')
url = 'https://quotes.wsj.com/'



wsj_ticker_prices<-NULL
for (i in 1:length(ticker_symbols)){
    price<-read_html(paste0(url,ticker_symbols[i]))%>%
        html_nodes("#quote_val")%>%
        html_text()
    wsj_ticker_prices<-rbind(wsj_ticker_prices,data.frame(ticker=ticker_symbols[i],price=price))
}


wsj_ticker_prices