######
#Get the Bank Names for Routing Numbers
######

library(rvest)
library(dplyr)

#Define the url
url <- "http://www.usbanklocations.com/"

#Read in the routing number data
num_df<-read.csv("G:/marketing/Marketing Analytics/Bohning_Jessica/Projects/2019/191021_Webscrapping Tutorial/Matt's Files/Routing numbers for lookup.csv")

#Subset the data to just the routing number
nums=num_df[,'ROUTING_TRANSMIT_NUMBER']

#Grab the node that contains the table
banks<-NULL
for (n in 1:length(nums)){
    scraping<-tryCatch({read_html(paste0(url,"routing-number-",nums[n],".html"))},
                        error= function(e) {
                            e='not a valid bank routing number'
                            return(e)
                            }
                        )
        
    if(scraping=='not a valid bank routing number'){
        banks_temp<-"'not a valid bank routing number'"
    }else{
        banks_temp <- scraping %>%
            html_nodes("#left tr:nth-child(1) a")%>%
            html_text()
    }
    if(length(banks_temp)==0){
        banks_temp <- scraping%>%
            html_nodes("table:nth-child(4) tr:nth-child(1) td+ td")%>%
            html_text()
        
    }
    if(length(banks_temp)==0){
        banks_temp <- NULL
        
    }
    
    
    banks<-rbind(banks,data.frame(routing_number=nums[n],bank_name=banks_temp))
    
}


write.csv(banks,"banks.csv")



