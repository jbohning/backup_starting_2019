######
#Get Price of Amazon Dinosaur Costume
######

library(rvest)
library(dplyr)

#Define the url
url <- "https://www.amazon.com/Rubies-Jurassic-Inflatable-Costume-Childs/dp/B00TO8QRC4/ref=cts_ap_1_vtp"

#Grab the node that contains the table
price <- url %>%
    read_html() %>%
    html_nodes("#priceblock_ourprice")%>%
    html_text()

price





