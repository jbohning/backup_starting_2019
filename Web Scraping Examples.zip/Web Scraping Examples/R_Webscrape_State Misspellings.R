####################

#This code navigates to the web page on 
#with the most common misspellings of
#US states, then grabs the table
#and saves it off

####################

#install the rvest package if you havent already
install.packages("rvest")

#load the rvest library
library(rvest)
library(dplyr)

#Definte the url
url <- "https://offices.net/misspelled-state-names.htm"

#Grab the node that contains the table
states <- url %>%
    read_html() %>%
    html_nodes("table") %>%
    html_table()

#Convert 'states' to data table
#It is currently a list
states<-data.frame(states[[1]])

#View data
head(states)

#Save data
write.csv(states, file="state_misspellings.csv")


#############################################
#OPTIONAL: you can clean up the data
#############################################
#Create new data set that we can clean
states_edited<-states

#Rename the columns
names(states_edited)<-c("state","misspelling")

#Each row in column 2 contains the same phrase. 
#Remove that string from all rows
states_edited$misspelling<-gsub("Commonly misspelled as ",replacement="",states_edited$misspelling)

#Some rows have just one letter (these were headings
#in the original table). Remove rows with just one character
states_edited<-states_edited[(which(nchar(states_edited$state)!=1)),]

#Save cleaned data off
write.csv(states_edited,"state_misspellings_cleaned.csv")