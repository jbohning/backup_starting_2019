#Using Wayback Machine to Get old TurboTax Pricing data
library(rvest)
library(dplyr)

#Get array of urls
startdate<-as.Date("2007/02/11",format="%Y/%m/%d")
number_of_days<-14

#First Get a List of Dates
datelist<-seq(startdate, startdate+number_of_days-1, by="days")

#Format those dates like "201701011" (like the website did)
#This will be used to construct the urls
datelist_e<-as.character(datelist)
datelist_e<-gsub(pattern="-",replacement = "",x=datelist)

#Format as a url
url_list<-paste0("https://web.archive.org/web/",datelist_e,"/https://turbotax.intuit.com/")

#Scrape data - go through each webpage
scraped_data<-NULL
for (i in 1:length(url_list)){
    scraping<-read_html(url_list[i])
    products<-scraping %>%
        html_nodes(".producthead h3") %>%
        html_text()
    prices<-scraping %>%
        html_nodes("em") %>%
        html_text()
    if(length(products)==0){
        products<-"error-missing data"
    }
    if(length(prices)==0){
        prices<-"error-missing data"
    }
    
    scraped_data<-rbind(scraped_data,
                        data.frame(datelist[i],products,prices))
}


scraped_data_edited<-data.frame(scraped_data)

write.csv(scraped_data_edited,"turbo_pricing.csv")

##############################################
#OPTIONAL: CLEAN DATA
##############################################
names(scraped_data_edited)<-c("Date","Products","Prices")

#Clean up pricing: remove \n and \t
scraped_data_edited$Prices<-gsub("\n|\t",replacement="",scraped_data_edited$Prices)

#format as numeric: remove dollar sign first
scraped_data_edited$Prices<-as.numeric(gsub(pattern="\\$",replacement="",scraped_data_edited$Prices))


#Save Data
filename<-paste0("wayback_machine_",startdate,"_",number_of_days,".csv")
write.csv(scraped_data_edited,file=filename)

