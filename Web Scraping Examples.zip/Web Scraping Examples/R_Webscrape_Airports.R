####################

#This code navigates to the Wikipedia page on 
#airport locations, grabs the table
#and saves it off

####################

#install the rvest package if you havent already
install.packages("rvest")

#load the rvest library
library(rvest)
library(dplyr)

#Definte the url
url <- "https://en.wikipedia.org/wiki/List_of_airports_in_the_United_States"

#Grab the node that contains the table
airports <- url %>%
    read_html() %>%
    html_nodes("table.sortable") %>%
    html_table(fill=TRUE)
airports <- airports[[1]]

#View data
View(airports)

#Save data
write.csv(airports, file="airport_locations.csv")

#############################################
#OPTIONAL: you can clean up the data
#############################################

#Note: there are sub-titles within the table
#That show the state the airport is in.
#You can eliminate this in multiple ways. 
#I chose to eliminate the rows that have no values
#for the Airport Name

airports_edited<-airports[airports$Airport != "",]


#We can also drop the last column because it is 
#mostly nulls
airports_edited<-airports_edited[,-8]
head(airports_edited)


#We can save this data off too
write.csv(airports_edited, file="airport_locations_cleaned.csv")